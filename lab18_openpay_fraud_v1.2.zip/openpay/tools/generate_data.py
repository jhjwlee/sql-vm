#!/usr/bin/env python3
"""
OpenPay 사기 탐지 실습용 가상 데이터 생성기
================================================
결정론적 시드를 사용하여 검증팀이 항상 동일한 결과를 재현할 수 있습니다.

생성되는 데이터:
- accounts.csv      : 500개 계좌 (정상 470 + 의심 30)
- devices.csv       : 350개 디바이스
- ip_addresses.csv  : 200개 IP 주소
- transactions.csv  : 약 5,000건 거래
- owns.csv          : 계좌-디바이스 소유 관계
- used.csv          : 계좌-IP 사용 관계

의도적으로 삽입한 사기 패턴 (총 5개 조직):
  ORG-1 : 자금세탁 순환 (4-hop cycle) - 계좌 ID 100~103
  ORG-2 : 디바이스 공모 (1 device, 8 accounts) - 계좌 ID 110~117
  ORG-3 : SMURFING (분할 송금) - 계좌 ID 120 → 121
  ORG-4 : IP 공모 (해외 프록시 IP0001 하나를 해외 계좌 6개가 공유) - 계좌 ID 130~135
  ORG-5 : 허브 계좌 (in-degree 비정상적으로 높음) - 계좌 ID 140
"""

import csv
import random
from datetime import datetime, timedelta
from pathlib import Path

# === 결정론적 시드 ===
SEED = 20260506
random.seed(SEED)

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "data"
OUTPUT_DIR.mkdir(exist_ok=True)

# === 기본 파라미터 ===
NUM_ACCOUNTS = 500
NUM_DEVICES = 350
NUM_IPS = 200
NUM_LEGIT_TRANSACTIONS = 4500

START_DATE = datetime(2026, 1, 1)
END_DATE = datetime(2026, 4, 30)

COUNTRIES = ["KR", "KR", "KR", "KR", "US", "JP", "CN", "VN", "PH"]  # KR 가중
SUSPICIOUS_COUNTRIES = ["RU", "KP", "IR"]  # ORG-4용

FIRST_NAMES = ["민준", "서연", "도윤", "지우", "하준", "서윤", "주원", "지호",
               "지유", "수아", "예준", "하은", "유준", "시우", "지안", "서현",
               "건우", "윤서", "현우", "예은", "정우", "수빈", "성민", "지원"]
LAST_NAMES = ["김", "이", "박", "최", "정", "강", "조", "윤", "장", "임", "한", "오", "서", "신"]

DEVICE_TYPES = ["iPhone", "Galaxy", "Pixel", "MacBook", "Windows-PC", "iPad"]


def random_datetime(start, end):
    """start~end 사이 임의 datetime 반환"""
    delta = end - start
    seconds = random.randint(0, int(delta.total_seconds()))
    return start + timedelta(seconds=seconds)


def fmt_dt(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


# ---------------------------------------------------------------------------
# 1) Accounts
# ---------------------------------------------------------------------------
accounts = []
for i in range(1, NUM_ACCOUNTS + 1):
    name = random.choice(LAST_NAMES) + random.choice(FIRST_NAMES)
    country = random.choice(COUNTRIES)
    # 의심 계좌(130~135)는 해외 국가
    if 130 <= i <= 135:
        country = random.choice(SUSPICIOUS_COUNTRIES)
    created = random_datetime(START_DATE - timedelta(days=365), START_DATE)
    accounts.append({
        "accountId": f"ACC{i:04d}",
        "name": name,
        "country": country,
        "createdAt": fmt_dt(created),
    })

# ---------------------------------------------------------------------------
# 2) Devices
# ---------------------------------------------------------------------------
devices = []
for i in range(1, NUM_DEVICES + 1):
    devices.append({
        "deviceId": f"DEV{i:04d}",
        "type": random.choice(DEVICE_TYPES),
        "fingerprint": f"fp_{random.randint(10**9, 10**10 - 1):x}",
    })

# ---------------------------------------------------------------------------
# 3) IP addresses
# ---------------------------------------------------------------------------
ips = []
for i in range(1, NUM_IPS + 1):
    ip = f"{random.randint(1, 223)}.{random.randint(0, 255)}." \
         f"{random.randint(0, 255)}.{random.randint(1, 254)}"
    ips.append({
        "ipId": f"IP{i:04d}",
        "address": ip,
        "country": random.choice(COUNTRIES + SUSPICIOUS_COUNTRIES),
        "isProxy": random.random() < 0.05,
    })

# ORG-4가 쓰는 IP0001은 해외(RU) 프록시 IP로 고정한다.
# (난수 소비 순서를 바꾸지 않도록 생성이 끝난 뒤 값만 덮어쓴다)
ips[0]["country"] = "RU"
ips[0]["isProxy"] = True

# ---------------------------------------------------------------------------
# 4) OWNS (Account -> Device)
# ---------------------------------------------------------------------------
owns = []
# 정상 계좌: 1~3개의 디바이스 보유, 디바이스는 보통 1명만 사용
account_ids = [a["accountId"] for a in accounts]
device_pool = list(range(1, NUM_DEVICES + 1))
random.shuffle(device_pool)
device_iter = iter(device_pool)

for acc in accounts:
    n_dev = random.choices([1, 2, 3], weights=[60, 30, 10])[0]
    used_devs = set()
    for _ in range(n_dev):
        try:
            dev_num = next(device_iter)
        except StopIteration:
            dev_num = random.randint(1, NUM_DEVICES)
        used_devs.add(dev_num)
    for d in used_devs:
        owns.append({
            "accountId": acc["accountId"],
            "deviceId": f"DEV{d:04d}",
            "since": fmt_dt(random_datetime(START_DATE - timedelta(days=200), START_DATE)),
        })

# ORG-2: 8개 계좌가 단일 디바이스(DEV0001) 공유
for acc_num in range(110, 118):
    owns.append({
        "accountId": f"ACC{acc_num:04d}",
        "deviceId": "DEV0001",
        "since": fmt_dt(random_datetime(START_DATE, START_DATE + timedelta(days=10))),
    })

# ---------------------------------------------------------------------------
# 5) USED (Account -> IPAddress)
# ---------------------------------------------------------------------------
used = []
for acc in accounts:
    n_ips = random.choices([1, 2, 3, 5], weights=[40, 30, 20, 10])[0]
    chosen = random.sample(range(1, NUM_IPS + 1), n_ips)
    for ip_num in chosen:
        used.append({
            "accountId": acc["accountId"],
            "ipId": f"IP{ip_num:04d}",
            "lastUsed": fmt_dt(random_datetime(START_DATE, END_DATE)),
        })

# ORG-4: 6개 계좌가 단일 IP(IP0001) 공유
for acc_num in range(130, 136):
    used.append({
        "accountId": f"ACC{acc_num:04d}",
        "ipId": "IP0001",
        "lastUsed": fmt_dt(random_datetime(START_DATE, END_DATE)),
    })

# ---------------------------------------------------------------------------
# 6) TRANSFERS
# ---------------------------------------------------------------------------
transactions = []
tx_id = 1

# 정상 거래
for _ in range(NUM_LEGIT_TRANSACTIONS):
    src, dst = random.sample(account_ids, 2)
    amount = round(random.lognormvariate(11, 1.2), 2)  # 평균 약 60~200만원
    transactions.append({
        "txId": f"TX{tx_id:06d}",
        "fromAccount": src,
        "toAccount": dst,
        "amount": amount,
        "currency": "KRW",
        "timestamp": fmt_dt(random_datetime(START_DATE, END_DATE)),
        "channel": random.choice(["MOBILE", "WEB", "ATM"]),
    })
    tx_id += 1

# === 사기 패턴 삽입 ===

# ORG-1: 자금세탁 순환 ACC0100 -> ACC0101 -> ACC0102 -> ACC0103 -> ACC0100
laundering_amount = 89_500_000
ring = ["ACC0100", "ACC0101", "ACC0102", "ACC0103", "ACC0100"]
ring_start = datetime(2026, 3, 15, 10, 0, 0)
for i in range(4):
    transactions.append({
        "txId": f"TX{tx_id:06d}",
        "fromAccount": ring[i],
        "toAccount": ring[i + 1],
        "amount": laundering_amount - i * 50_000,  # 수수료처럼 살짝 줄임
        "currency": "KRW",
        "timestamp": fmt_dt(ring_start + timedelta(hours=i * 3)),
        "channel": "MOBILE",
    })
    tx_id += 1

# ORG-3: SMURFING - ACC0120이 ACC0121에게 작은 금액 12회 송금 (총 약 1,200만원)
smurf_start = datetime(2026, 2, 10, 9, 0, 0)
for i in range(12):
    transactions.append({
        "txId": f"TX{tx_id:06d}",
        "fromAccount": "ACC0120",
        "toAccount": "ACC0121",
        "amount": round(random.uniform(950_000, 999_999), 2),  # CTR 기준 100만원 미만으로 분할
        "currency": "KRW",
        "timestamp": fmt_dt(smurf_start + timedelta(hours=i * 2)),
        "channel": "MOBILE",
    })
    tx_id += 1

# ORG-5: 허브 계좌 ACC0140이 80개 계좌로부터 송금받음
hub_senders = random.sample(
    [a for a in account_ids if a not in {"ACC0140"}],
    80,
)
for sender in hub_senders:
    transactions.append({
        "txId": f"TX{tx_id:06d}",
        "fromAccount": sender,
        "toAccount": "ACC0140",
        "amount": round(random.uniform(500_000, 5_000_000), 2),
        "currency": "KRW",
        "timestamp": fmt_dt(random_datetime(START_DATE, END_DATE)),
        "channel": "MOBILE",
    })
    tx_id += 1

# ---------------------------------------------------------------------------
# 파일 쓰기
# ---------------------------------------------------------------------------
def write_csv(name, rows, headers):
    path = OUTPUT_DIR / name
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        w.writerows(rows)
    print(f"  {path.name:25s} {len(rows):>6,d} rows")


print(f"[+] OpenPay 데이터 생성 (SEED={SEED})")
print(f"    출력 위치: {OUTPUT_DIR}")
print()
write_csv("accounts.csv", accounts, ["accountId", "name", "country", "createdAt"])
write_csv("devices.csv", devices, ["deviceId", "type", "fingerprint"])
write_csv("ip_addresses.csv", ips, ["ipId", "address", "country", "isProxy"])
write_csv("owns.csv", owns, ["accountId", "deviceId", "since"])
write_csv("used.csv", used, ["accountId", "ipId", "lastUsed"])
write_csv("transactions.csv", transactions,
          ["txId", "fromAccount", "toAccount", "amount", "currency", "timestamp", "channel"])
print()
print(f"[+] 총 거래 건수: {len(transactions):,}")
print(f"[+] 의도된 사기 패턴: 5개 조직 (ORG-1 ~ ORG-5)")
