// =====================================================================
// 04. 자금세탁 순환(ORG-1) — 출발한 돈이 4단계를 거쳐 다시 돌아온다
// =====================================================================

// 1) 4단계 순환 + 시간 순서 + 1천만 원 초과 — 정확히 1건
MATCH (a:Account)-[t1:TRANSFER]->(b:Account)-[t2:TRANSFER]->(c:Account)
                 -[t3:TRANSFER]->(d:Account)-[t4:TRANSFER]->(a)
WHERE a <> b AND a <> c AND a <> d AND b <> c AND b <> d AND c <> d
  AND t1.timestamp < t2.timestamp < t3.timestamp < t4.timestamp
  AND t1.amount > 10000000
RETURN a.accountId AS start, b.accountId AS hop1, c.accountId AS hop2, d.accountId AS hop3,
       [round(t1.amount), round(t2.amount), round(t3.amount), round(t4.amount)] AS amounts,
       duration.inSeconds(t1.timestamp, t4.timestamp).hours AS elapsed_hours;
// ACC0100 → 0101 → 0102 → 0103 → 0100 · 89,500,000 → 89,350,000 (5만 원씩 감소) · 9시간

// 2) 금액 조건을 빼면? — 시간 순서가 맞는 4단계 순환이 320건
MATCH (a:Account)-[t1:TRANSFER]->(b:Account)-[t2:TRANSFER]->(c:Account)
                 -[t3:TRANSFER]->(d:Account)-[t4:TRANSFER]->(a)
WHERE a <> b AND a <> c AND a <> d AND b <> c AND b <> d AND c <> d
  AND t1.timestamp < t2.timestamp < t3.timestamp < t4.timestamp
RETURN count(*) AS cycles;

// 3) 의심도 점수 — 금액이 비슷할수록, 빨리 돌수록 높다 (0~100)
MATCH (a:Account)-[t1:TRANSFER]->(b:Account)-[t2:TRANSFER]->(c:Account)
                 -[t3:TRANSFER]->(d:Account)-[t4:TRANSFER]->(a)
WHERE a <> b AND a <> c AND a <> d AND b <> c AND b <> d AND c <> d
  AND t1.timestamp < t2.timestamp < t3.timestamp < t4.timestamp
WITH a, b, c, d, [t1.amount, t2.amount, t3.amount, t4.amount] AS amts,
     duration.inSeconds(t1.timestamp, t4.timestamp).hours AS elapsed
WITH a, b, c, d, amts, elapsed, reduce(s = 0.0, x IN amts | s + x) / 4 AS avg_amt
WITH a, b, c, d, elapsed, avg_amt,
     sqrt(reduce(s = 0.0, x IN amts | s + (x - avg_amt) ^ 2) / 4) AS sd
RETURN [a.accountId, b.accountId, c.accountId, d.accountId] AS ring,
       round(avg_amt) AS avg_amount, elapsed AS elapsed_hours,
       round(100 * (0.5 / (1 + sd / avg_amt) + 0.5 / (1 + elapsed / 24.0))) AS score
ORDER BY score DESC
LIMIT 5;
// 1위 ORG-1 86점 · 2위 46점 — 점수 차이가 크다
