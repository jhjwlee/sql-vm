// =====================================================================
// 02. Cypher 기초 — MATCH · WHERE · RETURN · 집계
// Neo4j Browser에서 한 문장씩 실행하며 결과를 본다
// =====================================================================

// Q1. 계좌 다섯 개 — SQL의 SELECT TOP 5
MATCH (a:Account)
RETURN a.accountId, a.name, a.country
LIMIT 5;

// Q2. 국가별 계좌 수 — KR 229가 가장 많다
MATCH (a:Account)
RETURN a.country AS country, count(*) AS accounts
ORDER BY accounts DESC;

// Q3. 한 계좌와 그 주변을 그림으로 — Browser의 Graph 탭에서 보기
MATCH (a:Account {accountId: 'ACC0115'})-[r]-(x)
RETURN a, r, x;

// Q4. 보낸 송금 / 받은 송금 — 화살표 방향만 바꾼다
MATCH (a:Account {accountId: 'ACC0100'})-[t:TRANSFER]->(to:Account)
RETURN to.accountId AS to, t.amount AS amount, t.timestamp AS ts
ORDER BY ts;

MATCH (from:Account)-[t:TRANSFER]->(a:Account {accountId: 'ACC0100'})
RETURN from.accountId AS from, t.amount AS amount, t.timestamp AS ts
ORDER BY ts;

// Q5. 채널별 거래 수와 평균 금액 — MOBILE 1,625 · ATM 1,487 · WEB 1,484
MATCH ()-[t:TRANSFER]->()
RETURN t.channel AS channel, count(t) AS tx, round(avg(t.amount)) AS avg_amount
ORDER BY tx DESC;

// Q6. 특정 날짜의 큰 거래 — 2026-03-15에 1천만 원 넘는 거래 4건
MATCH (s:Account)-[t:TRANSFER]->(d:Account)
WHERE date(t.timestamp) = date('2026-03-15') AND t.amount > 10000000
RETURN s.accountId AS from, d.accountId AS to, t.amount AS amount, t.timestamp AS ts
ORDER BY ts;

// Q7. 3단계까지 돈이 흘러간 길 — 가변 길이 패턴은 반드시 LIMIT과 함께
MATCH path = (s:Account {accountId: 'ACC0100'})-[:TRANSFER*1..3]->(e:Account)
WHERE s <> e
RETURN [n IN nodes(path) | n.accountId] AS chain, length(path) AS hops,
       reduce(total = 0.0, r IN relationships(path) | total + r.amount) AS moved
ORDER BY moved DESC
LIMIT 10;
