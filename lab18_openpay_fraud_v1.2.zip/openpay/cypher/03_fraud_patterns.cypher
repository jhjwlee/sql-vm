// =====================================================================
// 03. 사기 패턴 탐지 — 다섯 조직(ORG-1 ~ ORG-5) 찾기
// =====================================================================

// [ORG-5] 허브 계좌 — 비정상적으로 많이 받는 계좌 (평균 약 9건)
MATCH (s:Account)-[t:TRANSFER]->(r:Account)
RETURN r.accountId AS account, count(t) AS in_count, round(sum(t.amount)) AS received
ORDER BY in_count DESC
LIMIT 5;
// ACC0140 86건 · 약 2억 1,137만 원 / 2위 ACC0121 20건

// [ORG-3] 분할 송금(smurfing) — 100만 원 미만을 같은 수신자에게 10회 이상
MATCH (s:Account)-[t:TRANSFER]->(r:Account)
WHERE t.amount < 1000000
WITH s, r, count(t) AS n_tx, sum(t.amount) AS total
WHERE n_tx >= 10
RETURN s.accountId AS sender, r.accountId AS receiver, n_tx,
       round(total) AS total_amount, round(total / n_tx) AS avg_amount;
// ACC0120 → ACC0121 · 12건 · 11,653,963 · 건당 971,164

// [ORG-2] 디바이스 공유 — 한 기기를 8개 이상의 계좌가 쓴다
MATCH (a:Account)-[:OWNS]->(d:Device)
WITH d, collect(a.accountId) AS accounts
WHERE size(accounts) >= 8
RETURN d.deviceId AS device, d.type AS type, size(accounts) AS n_accounts, accounts;
// DEV0001 · 10개 (ACC0110~0117 + ACC0200, ACC0258)

// [ORG-4] 1단계 — 해외 IP를 10개 이상의 계좌가 공유: 10건이나 나온다 (노이즈)
MATCH (a:Account)-[:USED]->(ip:IPAddress)
WITH ip, count(a) AS n_accounts
WHERE n_accounts >= 10 AND ip.country <> 'KR'
RETURN ip.ipId, ip.country, ip.isProxy, n_accounts
ORDER BY n_accounts DESC;

// [ORG-4] 2단계 — 프록시(우회) IP라는 조건을 더한다: IP0001 하나
MATCH (a:Account)-[:USED]->(ip:IPAddress)
WHERE ip.isProxy AND ip.country <> 'KR'
WITH ip, collect(a) AS accs
WHERE size(accs) >= 10
RETURN ip.ipId, ip.address, ip.country, size(accs) AS n_accounts,
       size([x IN accs WHERE x.country IN ['RU', 'KP', 'IR']]) AS high_risk_accounts;
// IP0001 · RU · 14개 계좌 · 그중 고위험 국가 계좌 6개

// [ORG-4] 3단계 — IP0001을 쓰는 계좌의 국가
MATCH (a:Account)-[:USED]->(:IPAddress {ipId: 'IP0001'})
RETURN a.country AS country, collect(a.accountId) AS accounts
ORDER BY size(accounts) DESC;
// KP·IR·RU 각 2개 = ACC0130~0135 (ORG-4 핵심)

// [연결] 두 조직을 잇는 계좌 — DEV0001과 IP0001을 모두 쓰는 계좌
MATCH (:Device {deviceId: 'DEV0001'})<-[:OWNS]-(a:Account)-[:USED]->(:IPAddress {ipId: 'IP0001'})
RETURN a.accountId, a.country;
// ACC0115 하나 — ORG-2의 계좌가 ORG-4의 IP도 쓴다

// [참고] 같은 기기와 같은 IP를 함께 쓰는 계좌 쌍 — 11쌍
MATCH (a:Account)-[:OWNS]->(d:Device)<-[:OWNS]-(b:Account),
      (a)-[:USED]->(ip:IPAddress)<-[:USED]-(b)
WHERE a.accountId < b.accountId
RETURN a.accountId, b.accountId, d.deviceId, ip.ipId
ORDER BY a.accountId;
