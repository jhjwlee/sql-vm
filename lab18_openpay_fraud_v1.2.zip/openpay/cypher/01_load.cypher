// =====================================================================
// 01. 스키마(제약 조건 · 인덱스)와 데이터 적재
// 실행: cypher-shell -u neo4j -p "$NEO4J_PASSWORD" -f ~/openpay/cypher/01_load.cypher
// 처음부터 다시 할 때는 06_reset.cypher를 먼저 실행한다
// =====================================================================

// 1) 고유성 제약 — 자동으로 인덱스가 만들어진다
CREATE CONSTRAINT account_id IF NOT EXISTS FOR (a:Account)   REQUIRE a.accountId IS UNIQUE;
CREATE CONSTRAINT device_id  IF NOT EXISTS FOR (d:Device)    REQUIRE d.deviceId  IS UNIQUE;
CREATE CONSTRAINT ip_id      IF NOT EXISTS FOR (i:IPAddress) REQUIRE i.ipId      IS UNIQUE;
CREATE INDEX account_country IF NOT EXISTS FOR (a:Account)   ON (a.country);
CREATE INDEX ip_country      IF NOT EXISTS FOR (i:IPAddress) ON (i.country);

// 2) 노드 — MERGE라서 다시 실행해도 중복되지 않는다
LOAD CSV WITH HEADERS FROM 'file:///accounts.csv' AS row
MERGE (a:Account {accountId: row.accountId})
SET a.name = row.name, a.country = row.country, a.createdAt = datetime(row.createdAt);

LOAD CSV WITH HEADERS FROM 'file:///devices.csv' AS row
MERGE (d:Device {deviceId: row.deviceId})
SET d.type = row.type, d.fingerprint = row.fingerprint;

LOAD CSV WITH HEADERS FROM 'file:///ip_addresses.csv' AS row
MERGE (i:IPAddress {ipId: row.ipId})
SET i.address = row.address, i.country = row.country, i.isProxy = toBoolean(row.isProxy);

// 3) 관계 — 양 끝 노드를 MATCH로 찾고 잇는다. 큰 파일은 1,000행씩 나눠 커밋
LOAD CSV WITH HEADERS FROM 'file:///owns.csv' AS row
CALL (row) {
  MATCH (a:Account {accountId: row.accountId})
  MATCH (d:Device  {deviceId:  row.deviceId})
  MERGE (a)-[r:OWNS]->(d)
  SET r.since = datetime(row.since)
} IN TRANSACTIONS OF 1000 ROWS;

LOAD CSV WITH HEADERS FROM 'file:///used.csv' AS row
CALL (row) {
  MATCH (a:Account   {accountId: row.accountId})
  MATCH (i:IPAddress {ipId:      row.ipId})
  MERGE (a)-[r:USED]->(i)
  SET r.lastUsed = datetime(row.lastUsed)
} IN TRANSACTIONS OF 1000 ROWS;

// 송금은 같은 두 계좌 사이에 여러 건이 있을 수 있다 → txId로 MERGE
LOAD CSV WITH HEADERS FROM 'file:///transactions.csv' AS row
CALL (row) {
  MATCH (src:Account {accountId: row.fromAccount})
  MATCH (dst:Account {accountId: row.toAccount})
  MERGE (src)-[t:TRANSFER {txId: row.txId}]->(dst)
  SET t.amount = toFloat(row.amount), t.currency = row.currency,
      t.timestamp = datetime(row.timestamp), t.channel = row.channel
} IN TRANSACTIONS OF 1000 ROWS;

// 4) 적재 확인 — Account 500 · Device 350 · IPAddress 200 · OWNS 746 · USED 1061 · TRANSFER 4596
CALL () { MATCH (a:Account)   RETURN 'Account'   AS item, count(a) AS cnt
  UNION ALL MATCH (d:Device)    RETURN 'Device'    AS item, count(d) AS cnt
  UNION ALL MATCH (i:IPAddress) RETURN 'IPAddress' AS item, count(i) AS cnt
  UNION ALL MATCH ()-[r:OWNS]->()     RETURN 'OWNS'     AS item, count(r) AS cnt
  UNION ALL MATCH ()-[r:USED]->()     RETURN 'USED'     AS item, count(r) AS cnt
  UNION ALL MATCH ()-[r:TRANSFER]->() RETURN 'TRANSFER' AS item, count(r) AS cnt }
RETURN item, cnt;
