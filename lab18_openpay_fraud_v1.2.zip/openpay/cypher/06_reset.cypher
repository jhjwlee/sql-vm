// 처음부터 다시 할 때 — 모든 노드와 관계를 지운다 (제약 조건 · 인덱스는 남는다)
MATCH (n) CALL (n) { DETACH DELETE n } IN TRANSACTIONS OF 1000 ROWS;
