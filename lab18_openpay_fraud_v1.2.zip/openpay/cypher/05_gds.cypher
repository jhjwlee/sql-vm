// =====================================================================
// 05. GDS 그래프 알고리즘 — PageRank · WCC
// GDS는 그래프의 일부를 메모리에 투영(projection)한 뒤 알고리즘을 실행한다
// =====================================================================
RETURN gds.version();                                    // 2.13.x

// 1) 송금 그래프 투영 → PageRank (금액 가중)
CALL gds.graph.project('transfers', 'Account', {TRANSFER: {properties: 'amount'}})
YIELD graphName, nodeCount, relationshipCount;           // 500 · 4596

CALL gds.pageRank.stream('transfers', {maxIterations: 20, dampingFactor: 0.85, relationshipWeightProperty: 'amount'})
YIELD nodeId, score
RETURN gds.util.asNode(nodeId).accountId AS account, round(score, 2) AS pagerank
ORDER BY pagerank DESC
LIMIT 5;
// ACC0140 약 39.2로 1위, 2위 ACC0484 약 7.8 — 1위는 단순 집계(86건)와 같은 계좌,
// 2~5위는 ACC0140이 돈을 보낸 상위 네 계좌

// 2) 공유 자원 그래프 투영 → WCC: 모든 계좌가 한 덩어리가 된다
CALL gds.graph.project('shared', ['Account', 'Device', 'IPAddress'],
     {OWNS: {orientation: 'UNDIRECTED'}, USED: {orientation: 'UNDIRECTED'}})
YIELD graphName, nodeCount, relationshipCount;           // 1050 · 3614
// 저장된 관계는 1,807개(OWNS 746 + USED 1,061). 무방향 투영은 양쪽 방향을 모두 세므로 두 배로 표시된다

CALL gds.wcc.stream('shared') YIELD nodeId, componentId
WITH componentId, gds.util.asNode(nodeId) AS n
WHERE n:Account
RETURN componentId, count(*) AS accounts
ORDER BY accounts DESC
LIMIT 3;
// 500 — 정상 계좌도 IP를 공유하므로 전부 연결된다

// 3) 고위험 자원만 투영 → WCC: 기기 6개 이상 공유 · 프록시 IP 10개 이상 공유
MATCH (a:Account)-[:OWNS|USED]->(r)
WHERE (r:Device AND COUNT { (r)<-[:OWNS]-() } >= 6)
   OR (r:IPAddress AND r.isProxy AND COUNT { (r)<-[:USED]-() } >= 10)
WITH gds.graph.project('risky', a, r, {}, {undirectedRelationshipTypes: ['*']}) AS g
RETURN g.graphName, g.nodeCount, g.relationshipCount;    // 25 · 48
// 노드 25 = 계좌 23 + 자원 2(DEV0001·IP0001), 관계 24개(10 + 14)를 무방향으로 세어 48

CALL gds.wcc.stream('risky') YIELD nodeId, componentId
WITH componentId, gds.util.asNode(nodeId) AS n
WITH componentId, [x IN collect(n) WHERE x:Account | x.accountId] AS members,
                  [x IN collect(n) WHERE NOT x:Account | coalesce(x.deviceId, x.ipId)] AS resources
RETURN componentId, size(members) AS accounts, resources, members;
// 1행 · 계좌 23개 · [DEV0001, IP0001] — ORG-2와 ORG-4가 ACC0115로 이어진 하나의 집단

// 4) 메모리 정리 — 투영한 그래프는 지우지 않으면 메모리에 남는다
CALL gds.graph.drop('transfers') YIELD graphName RETURN graphName;
CALL gds.graph.drop('shared')    YIELD graphName RETURN graphName;
CALL gds.graph.drop('risky')     YIELD graphName RETURN graphName;
CALL gds.graph.list()            YIELD graphName RETURN graphName;   // 결과 없음
