#!/usr/bin/env bash
# =====================================================================
# OpenPay 사기 탐지 실습 — Neo4j 설치 스크립트
# 대상: Azure VM Standard_B2ms (2 vCPU / 8 GiB), Ubuntu Server 24.04 LTS
# 설치: Java 21 · Neo4j Community 5.26 LTS · GDS(Graph Data Science) 2.13
# 실행: NEO4J_PASSWORD='내가 정한 암호' bash ~/openpay/setup/install_neo4j.sh
#       (암호를 주지 않으면 실행 중에 묻는다. 8자 이상)
# =====================================================================
set -euo pipefail

NEO4J_SERIES="5.26"          # LTS 계열 — 이 계열의 최신 패치를 설치한다
GDS_VERSION="2.13.4"         # Neo4j 5.26을 지원하는 GDS 계열 (공식 호환표)
LAB_HOME="$(cd "$(dirname "$0")/.." && pwd)"
log() { echo -e "\n\033[1;34m[setup] $*\033[0m"; }

if [ -z "${NEO4J_PASSWORD:-}" ]; then
  read -r -s -p "Neo4j 'neo4j' 사용자의 암호를 정하세요 (8자 이상): " NEO4J_PASSWORD; echo
fi
[ "${#NEO4J_PASSWORD}" -ge 8 ] || { echo "암호는 8자 이상이어야 합니다."; exit 1; }

log "1/6 Java 21과 Neo4j 저장소"
sudo apt-get update -y -q
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -q openjdk-21-jre-headless curl gnupg
curl -fsSL https://debian.neo4j.com/neotechnology.gpg.key | sudo gpg --dearmor --yes -o /usr/share/keyrings/neo4j.gpg
echo 'deb [signed-by=/usr/share/keyrings/neo4j.gpg] https://debian.neo4j.com stable 5' \
  | sudo tee /etc/apt/sources.list.d/neo4j.list >/dev/null
sudo apt-get update -y -q

log "2/6 Neo4j ${NEO4J_SERIES} 최신 패치 설치"
# awk에서 exit하면 apt-cache가 SIGPIPE(141)로 끝나 pipefail + set -e에 걸린다 — 끝까지 읽고 END에서 출력
VER="$(apt-cache madison neo4j | awk -v s="1:${NEO4J_SERIES}." '!v && $3 ~ "^"s {v=$3} END {print v}')"
[ -n "$VER" ] || { echo "저장소에서 neo4j ${NEO4J_SERIES}.x를 찾지 못했습니다."; exit 1; }
echo "  설치 버전: $VER"
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -q "neo4j=${VER}"
sudo apt-mark hold neo4j >/dev/null           # 자동 업그레이드로 GDS와 버전이 어긋나지 않게
sudo systemctl stop neo4j 2>/dev/null || true

log "3/6 설정: 외부 접속 · 메모리 · GDS 허용"
CONF=/etc/neo4j/neo4j.conf
sudo sed -i 's/^#\?server.default_listen_address=.*/server.default_listen_address=0.0.0.0/' "$CONF"
sudo sed -i 's/^#\?server.memory.heap.initial_size=.*/server.memory.heap.initial_size=2g/' "$CONF"
sudo sed -i 's/^#\?server.memory.heap.max_size=.*/server.memory.heap.max_size=2g/' "$CONF"
sudo sed -i 's/^#\?server.memory.pagecache.size=.*/server.memory.pagecache.size=1g/' "$CONF"
grep -q '^dbms.security.procedures.unrestricted=gds' "$CONF" \
  || echo 'dbms.security.procedures.unrestricted=gds.*' | sudo tee -a "$CONF" >/dev/null

log "4/6 GDS ${GDS_VERSION} 플러그인"
GDS_JAR="/var/lib/neo4j/plugins/neo4j-graph-data-science-${GDS_VERSION}.jar"
if [ ! -s "$GDS_JAR" ]; then
  sudo curl -fL --retry 3 -o "$GDS_JAR" \
    "https://github.com/neo4j/graph-data-science/releases/download/${GDS_VERSION}/neo4j-graph-data-science-${GDS_VERSION}.jar" \
    || { echo "  ⚠ GDS를 내려받지 못했습니다 — 5부(GDS)를 빼고 진행할 수 있습니다."; sudo rm -f "$GDS_JAR"; }
fi
[ -f "$GDS_JAR" ] && sudo chown neo4j:neo4j "$GDS_JAR"

log "5/6 초기 암호 설정 후 시작"
# 초기 암호는 '처음 시작하기 전'에만 설정할 수 있다
if sudo -u neo4j neo4j-admin dbms set-initial-password "$NEO4J_PASSWORD" 2>/dev/null; then
  echo "  초기 암호 설정 완료"
else
  echo "  (이미 시작된 적이 있는 데이터베이스 — 시작 후 암호를 바꾼다)"; CHANGE_AFTER=1
fi
sudo systemctl enable --now neo4j
wait_up() { for _ in $(seq 1 60); do curl -fs http://localhost:7474 >/dev/null 2>&1 && return 0; sleep 2; done; return 1; }
if ! wait_up; then
  if [ -f "$GDS_JAR" ]; then
    echo "  ⚠ Neo4j가 시작하지 않습니다 — GDS 플러그인을 빼고 다시 시작합니다."
    sudo mv "$GDS_JAR" "$HOME/"; sudo systemctl restart neo4j; wait_up || { sudo journalctl -u neo4j -n 30 --no-pager; exit 1; }
  else
    sudo journalctl -u neo4j -n 30 --no-pager; exit 1
  fi
fi
if [ "${CHANGE_AFTER:-0}" = 1 ]; then
  cypher-shell -u neo4j -p neo4j -d system "ALTER CURRENT USER SET PASSWORD FROM 'neo4j' TO '${NEO4J_PASSWORD}';" \
    || echo "  ⚠ 기본 암호(neo4j)가 아닙니다 — 처음 정한 암호를 그대로 쓰세요."
fi
for _ in $(seq 1 20); do cypher-shell -u neo4j -p "$NEO4J_PASSWORD" "RETURN 1;" >/dev/null 2>&1 && break; sleep 3; done

log "6/6 실습 데이터 배치"
sudo cp "$LAB_HOME"/data/*.csv /var/lib/neo4j/import/
sudo chown neo4j:neo4j /var/lib/neo4j/import/*.csv
cat > "$HOME/.openpay.env" <<ENV
export NEO4J_USER=neo4j
export NEO4J_PASSWORD='${NEO4J_PASSWORD}'
ENV
chmod 600 "$HOME/.openpay.env"
grep -q 'openpay.env' "$HOME/.bashrc" || echo 'source ~/.openpay.env' >> "$HOME/.bashrc"

echo
echo "============================================================"
echo "  Neo4j    : $(neo4j --version 2>/dev/null || echo "$VER")"
echo "  GDS      : $( [ -f "$GDS_JAR" ] && echo "$GDS_VERSION" || echo '설치 안 됨')"
echo "  Browser  : http://<VM 공용 IP>:7474   (사용자 neo4j / 방금 정한 암호)"
echo "  다음     : source ~/.bashrc  →  bash ~/openpay/setup/check_neo4j.sh"
echo "============================================================"
