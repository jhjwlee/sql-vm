#!/usr/bin/env bash
# 설치 확인 — 모든 줄이 OK이면 다음 단계로
source "$HOME/.openpay.env"
# 한글은 화면에서 두 칸을 차지한다. printf %-22s는 바이트 기준이라 줄이 어긋나므로 '바이트 수 - 한글 수'로 폭을 계산한다
pad()  { local s="$1" b h; b=$(printf '%s' "$s" | wc -c); h=$(printf '%s' "$s" | LC_ALL=C tr -cd '\340-\357' | wc -c); printf '%s%*s' "$s" $((22 - b + h)) ''; }
ok()   { printf "  %s \033[1;32mOK\033[0m  %s\n" "$(pad "$1")" "$2"; }
fail() { printf "  %s \033[1;31mFAIL\033[0m %s\n" "$(pad "$1")" "$2"; }
q()    { cypher-shell -u "$NEO4J_USER" -p "$NEO4J_PASSWORD" --format plain "$1" 2>&1 | tail -n 1 | tr -d '"'; }
echo "[check] OpenPay Neo4j 환경"
systemctl is-active --quiet neo4j && ok "Neo4j 서비스" "active" || fail "Neo4j 서비스" "sudo journalctl -u neo4j -n 50"
v="$(q 'CALL dbms.components() YIELD versions RETURN versions[0];')"; [[ "$v" == *5.26* ]] && ok "Neo4j 버전" "$v" || fail "Neo4j 버전" "$v"
g="$(q 'RETURN gds.version();')"; [[ "$g" == *2.13* ]] && ok "GDS 플러그인" "$g" || fail "GDS 플러그인" "5부 전에 해결 (자주 만나는 문제)"
n="$(ls /var/lib/neo4j/import/*.csv 2>/dev/null | wc -l)"; [ "$n" = 6 ] && ok "CSV 파일" "6개 /var/lib/neo4j/import" || fail "CSV 파일" "${n}개"
curl -fs http://localhost:7474 >/dev/null && ok "Browser (7474)" "응답" || fail "Browser (7474)" "응답 없음"
