# OpenPay 사기 탐지 실습 (Lab18) — Neo4j + GDS

가상의 간편결제 회사 OpenPay의 계좌·기기·IP·송금 데이터를 Neo4j에 올리고,
Cypher 질의와 그래프 알고리즘으로 다섯 개의 사기 조직(ORG-1 ~ ORG-5)을 찾아냅니다.

## 구성

| 경로 | 내용 |
|---|---|
| `setup/install_neo4j.sh` | Java 21 · Neo4j Community 5.26 LTS · GDS 2.13 설치, 초기 암호 지정, CSV 복사 |
| `setup/check_neo4j.sh` | 설치 확인 (서비스 · 버전 · GDS · CSV · 7474 포트) |
| `data/*.csv` | 계좌 500 · 기기 350 · IP 200 · OWNS 746 · USED 1,061 · TRANSFER 4,596 |
| `cypher/01_load.cypher` | 제약 조건 · 인덱스 · LOAD CSV 적재 · 건수 확인 |
| `cypher/02_explore.cypher` | Cypher 기초 (Q1 ~ Q7) |
| `cypher/03_fraud_patterns.cypher` | 허브 · 분할 송금 · 기기 공유 · 프록시 IP · 조직 연결 |
| `cypher/04_cycles.cypher` | 자금세탁 순환 탐지와 의심도 점수 |
| `cypher/05_gds.cypher` | GDS PageRank · WCC |
| `cypher/06_reset.cypher` | 전체 삭제 (처음부터 다시 할 때) |
| `tools/generate_data.py` | 데이터 생성기 (seed 42, 다시 만들어도 같은 데이터) |

## 빠른 시작 (VM에서)

```bash
unzip lab18_openpay_fraud_v1.2.zip -d ~ && cd ~/openpay
NEO4J_PASSWORD='Openpay_2026' bash setup/install_neo4j.sh
bash setup/check_neo4j.sh
source ~/.openpay.env
cypher-shell -u neo4j -p "$NEO4J_PASSWORD" -f cypher/01_load.cypher
```

이후 `02` ~ `05`는 브라우저(`http://<VM 공용 IP>:7474`)에서 한 문장씩 실행합니다.
Neo4j Browser에서 `CALL { } IN TRANSACTIONS` 문장을 직접 실행할 때는 맨 앞에 `:auto`를 붙입니다.

## 데이터 생성기

seed 42로 고정해 몇 번을 다시 만들어도 같은 CSV가 나옵니다. ORG-4가 쓰는 IP0001은
러시아(RU) 프록시 IP로 고정되어 있어 "해외 프록시 IP를 여러 계좌가 공유" 패턴이 검출됩니다.

```bash
python3 tools/generate_data.py   # data/ 폴더의 CSV 6개를 다시 만든다
```
