# Lab17b 실습 자료 — pyspark 셸로 파이프라인 들여다보기

Lab17(OneStore 데이터 파이프라인)을 6부까지 마친 VM에서 이어서 합니다.
실습서 `51b_lab17b.Spark_셸로_들여다보기`를 따라 진행합니다.
같은 내용을 pyspark 셸로 해도 되고, JupyterLab 노트북으로 해도 됩니다(실습서 부록 C).

## 폴더 구성

| 경로 | 내용 |
|------|------|
| `tools/check_ready.sh` | 시작 전 확인 (Spark · Bronze · Silver 468건 · 접속 정보 · 포트 4040) |
| `snippets/part1_start.py` | 1부 셸에 붙여 넣을 코드 |
| `snippets/part2_dataframe.py` | 2부 DataFrame과 지연 실행 |
| `snippets/part3_sql_parquet.py` | 3부 Spark SQL과 Parquet |
| `notebooks/spark_ui_handson.ipynb` | 1~4부 전체를 셀 단위로 옮긴 노트북 (해설 · 주석 포함, AQE 실험 추가) |
| `tools/setup_jupyter.sh` | JupyterLab을 `~/jlab` 가상 환경에 설치 (한 번만) |
| `tools/start_jupyter.sh` | Spark 경로와 접속 정보를 넘겨 JupyterLab 띄우기 |
| `tools/cleanup.sh` | 이 실습이 만든 `/data/sparklab`만 지운다 |

snippets 파일은 한 번에 실행하는 스크립트가 아닙니다. `pyspark` 셸의 `>>>` 프롬프트에 블록 단위로 붙여 넣습니다.

## 빠른 순서 — pyspark 셸

```bash
ssh -L 4040:localhost:4040 azureuser@<VM 공용 IP>     # 내 PC에서 — Spark UI 터널
bash ~/sparklab/tools/check_ready.sh                    # VM에서
source $LAB_HOME/config/pipeline.env
pyspark                                                 # 내 PC 브라우저: http://localhost:4040
```

## 빠른 순서 — JupyterLab 노트북

```bash
ssh -L 8888:localhost:8888 -L 4040:localhost:4040 azureuser@<VM 공용 IP>   # 내 PC에서 — 터널 두 개
bash ~/sparklab/tools/check_ready.sh                    # VM에서
bash ~/sparklab/tools/setup_jupyter.sh                  # 처음 한 번만 (1~2분)
bash ~/sparklab/tools/start_jupyter.sh                  # 찍힌 http://127.0.0.1:8888/lab?token=… 를 내 PC 브라우저로
```

노트북은 `spark_ui_handson.ipynb` 하나만 엽니다. Spark UI는 1-2 셀을 실행한 뒤 http://localhost:4040 에서 열립니다.
JupyterLab은 띄운 창에서 Ctrl+C → y 로 끕니다.

이 실습이 쓰는 폴더는 `/data/sparklab`와 `~/jlab`(노트북을 쓸 때) 둘입니다. Lab17의 Bronze · Silver 데이터는 읽기만 합니다.
