# Lab17b 1부 Spark 띄우기 — pyspark 셸(>>>)에 블록 단위로 붙여 넣는다
# 파일 전체를 한 번에 실행하는 스크립트가 아니다. 실습서 순서대로 블록 하나씩 복사한다.

# ---- 1-4 설정 확인
spark.version
sc.master
spark.conf.get("spark.sql.shuffle.partitions")
spark.conf.get("spark.sql.session.timeZone")
