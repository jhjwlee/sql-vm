# Lab17b 3부 Spark SQL과 Parquet — pyspark 셸(>>>)에 블록 단위로 붙여 넣는다
# 파일 전체를 한 번에 실행하는 스크립트가 아니다. 실습서 순서대로 블록 하나씩 복사한다.

# ---- 3-1 임시 뷰와 SQL
events.createOrReplaceTempView("events")
spark.sql("""
SELECT channel, count(*) AS events, sum(qty * unit_price) AS amount
FROM events
WHERE event_type = 'ORDER_PLACED'
GROUP BY channel
ORDER BY channel
""").show()

# ---- 3-2 Silver를 JDBC로 읽기
import os
pg = {"url": "jdbc:postgresql://localhost:5432/onestore", "driver": "org.postgresql.Driver",
      "user": os.environ["PGUSER"], "password": os.environ["PGPASSWORD"]}
orders = spark.read.format("jdbc").options(**pg).option("dbtable", "silver.orders").load()
orders.printSchema()
orders.count()

# ---- 3-2 조건을 PostgreSQL로 넘기기 (pushdown)
orders.filter("channel = 'store' AND status = 'CANCELLED'").explain()

# ---- 3-3 KST 날짜로 다시 집계 — lab17 Gold와 비교
orders.createOrReplaceTempView("orders")
spark.sql("""
SELECT to_date(from_utc_timestamp(ordered_at, 'Asia/Seoul')) AS sales_date,
       count(*) AS orders,
       sum(CASE WHEN status = 'CANCELLED' THEN 1 ELSE 0 END) AS cancelled_orders,
       sum(CASE WHEN status = 'PLACED' THEN amount ELSE 0 END) AS revenue
FROM orders
GROUP BY 1
ORDER BY 1
""").show()

# ---- 3-3 UTC 날짜로 묶으면?
spark.sql("SELECT to_date(ordered_at) AS utc_date, count(*) AS orders FROM orders GROUP BY 1 ORDER BY 1").show()

# ---- 3-4 날짜별 폴더로 Parquet 쓰기
path = "/data/sparklab/orders_by_date"
(orders.withColumn("sales_date", F.to_date(F.from_utc_timestamp("ordered_at", "Asia/Seoul")))
       .write.mode("overwrite").partitionBy("sales_date").parquet(path))
sorted(f for f in os.listdir(path) if not f.startswith("."))
sorted(f for f in os.listdir(path + "/sales_date=2026-10-06") if not f.startswith("."))

# ---- 3-4 다시 읽기
o2 = spark.read.parquet(path)
o2.printSchema()

# ---- 3-4 파티션 프루닝
oct6 = o2.filter("sales_date = '2026-10-06'")
oct6.explain()
oct6.count()

# ---- 3-5 CSV로 쓰고 header만으로 읽기
csv_path = "/data/sparklab/orders_csv"
orders.write.mode("overwrite").option("header", True).csv(csv_path)
c1 = spark.read.option("header", True).csv(csv_path)
c1.printSchema()

# ---- 3-5 inferSchema로 읽기
c2 = spark.read.option("header", True).option("inferSchema", True).csv(csv_path)
c2.printSchema()

# ---- 3-5 스키마를 지정해서 읽기
c3 = spark.read.option("header", True).schema(orders.schema).csv(csv_path)
c3.printSchema()
c3.agg(F.sum("amount")).show()
