# Lab17b 2부 DataFrame과 지연 실행 — pyspark 셸(>>>)에 블록 단위로 붙여 넣는다
# 파일 전체를 한 번에 실행하는 스크립트가 아니다. 실습서 순서대로 블록 하나씩 복사한다.

# ---- 2-1 Bronze 읽기
bronze = spark.read.parquet("/data/bronze/orders")
bronze.printSchema()

# ---- 2-2 액션 두 개 — count와 show
bronze.count()
bronze.select("partition", "offset", "kafka_key", "ingest_date").orderBy("partition", "offset").show(3)

# ---- 2-3 변환은 계획만 세운다 (Job이 생기지 않는다)
from pyspark.sql import functions as F
schema = "event_id STRING, event_type STRING, order_id STRING, customer_id STRING, product_id STRING, qty INT, unit_price INT, channel STRING, event_ts STRING"
events = bronze.select(F.from_json("raw_value", schema).alias("e")).select("e.*")
placed = events.filter(F.col("event_type") == "ORDER_PLACED")
big = (placed.filter(F.col("qty") >= 3)
             .withColumn("amount", F.col("qty") * F.col("unit_price"))
             .select("order_id", "product_id", "qty", "unit_price", "amount"))

# ---- 2-3 액션을 부르면 그때 실행된다
big.show(5)
big.count()

# ---- 2-3 일부러 틀린 열 이름 — 오류가 바로 난다 (정상)
placed.filter(F.col("quantity") >= 3)

# ---- 2-4 실행 계획 읽기
big.explain()

# ---- 2-4 셔플이 들어간 계획
by_channel = (placed.groupBy("channel")
                    .agg(F.count("*").alias("events"),
                         F.sum(F.col("qty") * F.col("unit_price")).alias("amount")))
by_channel.explain()

# ---- 2-4 실행
by_channel.show()

# ---- 2-5 캐시
events.cache()
events.count()
events.count()

# ---- 2-5 캐시에서 읽는 계획 / from_json이 해석하지 못한 행
events.filter(F.col("event_type").isNull()).count()
events.filter(F.col("event_type").isNull()).explain()

# ---- 2-5 캐시 해제
events.unpersist()
