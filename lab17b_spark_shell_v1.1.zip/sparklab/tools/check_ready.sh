#!/usr/bin/env bash
# lab17b 시작 전 확인 — 모든 줄이 OK이면 1-3으로
source /etc/profile.d/onestore.sh 2>/dev/null
source "$LAB_HOME/config/pipeline.env" 2>/dev/null
ok()   { printf "  %-14s \033[1;32mOK\033[0m    %s\n" "$1" "$2"; }
fail() { printf "  %-14s \033[1;31mFAIL\033[0m  %s\n" "$1" "$2"; }

echo "[check] lab17b 시작 전 확인"
v="$(spark-submit --version 2>&1 | grep -m1 -o 'version [0-9.]*')"
[ -n "$v" ] && ok "Spark" "$v" || fail "Spark" "spark-submit을 찾을 수 없음 → source ~/.bashrc"
if [ -d /data/bronze/orders/_spark_metadata ]; then ok "Bronze" "/data/bronze/orders"
else fail "Bronze" "/data/bronze/orders 없음 → lab17 3부"; fi
n="$(psql -tAc 'SELECT count(*) FROM silver.orders' 2>/dev/null)"
if [ "$n" = "468" ]; then ok "Silver" "silver.orders ${n}건"
elif [ -n "$n" ]; then fail "Silver" "silver.orders ${n}건 (기대 468) → lab17 6부까지 완료했는지 확인"
else fail "Silver" "PostgreSQL 접속 실패 → sudo systemctl start postgresql"; fi
if [ -n "${PGUSER:-}" ] && [ -n "${PGPASSWORD:-}" ]; then ok "pipeline.env" "PGUSER=$PGUSER"
else fail "pipeline.env" "$LAB_HOME/config/pipeline.env를 읽지 못함"; fi
if ss -ltn 2>/dev/null | grep -q ':4040 '; then fail "port 4040" "이미 사용 중 — 다른 창의 pyspark/spark-submit을 끝낸다"
else ok "port 4040" "비어 있음"; fi
