#!/usr/bin/env bash
# lab17b 노트북판 준비 — JupyterLab을 ~/jlab 가상 환경에 설치한다 (VM에서 한 번만)
#  - Ubuntu 24.04는 시스템 파이썬에 pip로 직접 설치하는 것을 막아 두었으므로 가상 환경(venv)을 따로 만든다.
#  - pyspark는 설치하지 않는다. /opt/spark에 들어 있는 Spark 3.5.9의 pyspark를 그대로 쓴다(start_jupyter.sh).
set -euo pipefail
VENV="$HOME/jlab"

echo "[setup] 1/3 python3-venv 확인"
if ! python3 -c "import ensurepip" 2>/dev/null; then
  sudo apt-get update -q
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -q python3-venv
fi

echo "[setup] 2/3 가상 환경 만들기: $VENV"
[ -x "$VENV/bin/python" ] || python3 -m venv "$VENV"

echo "[setup] 3/3 JupyterLab 설치 (1~2분)"
"$VENV/bin/pip" install -q --upgrade pip
"$VENV/bin/pip" install -q "jupyterlab==4.6.4"

echo "[setup] 완료 — $("$VENV/bin/jupyter" lab --version | sed 's/^/JupyterLab /')"
echo "        다음: bash ~/sparklab/tools/start_jupyter.sh"
