#!/usr/bin/env bash
# lab17b가 만든 폴더만 지운다 (lab17의 Bronze · Silver는 그대로)
rm -rf /data/sparklab
echo "[cleanup] /data/sparklab 삭제 완료 — lab17 데이터는 그대로입니다"
