#!/usr/bin/env bash
# lab17b 노트북판 — JupyterLab 띄우기
#  이 스크립트로 띄워야 노트북 커널이 Spark 경로와 PostgreSQL 접속 정보를 물려받는다.
#  끝낼 때는 이 창에서 Ctrl+C → y
set -euo pipefail
VENV="$HOME/jlab"
PORT="${1:-8888}"

source /etc/profile.d/onestore.sh                # SPARK_HOME, LAB_HOME, PATH (Lab17 설치 스크립트가 만든 파일)
set -a; source "$LAB_HOME/config/pipeline.env"; set +a   # PGUSER, PGPASSWORD … (3-2에서 사용)

# /opt/spark에 들어 있는 pyspark와 py4j를 import할 수 있게 경로를 잡는다
PY4J="$(ls "$SPARK_HOME"/python/lib/py4j-*-src.zip | head -n 1)"
export PYTHONPATH="$SPARK_HOME/python:$PY4J${PYTHONPATH:+:$PYTHONPATH}"
export PYSPARK_PYTHON="$VENV/bin/python"         # 드라이버와 같은 파이썬을 쓰게 맞춘다

[ -x "$VENV/bin/jupyter" ] || { echo "JupyterLab이 없습니다 → bash ~/sparklab/tools/setup_jupyter.sh"; exit 1; }
if ss -ltn 2>/dev/null | grep -q ":$PORT "; then
  echo "포트 $PORT 이 이미 사용 중입니다. 다른 창의 JupyterLab을 끄거나 다른 포트로: bash $0 8889"; exit 1
fi

cd "$HOME/sparklab/notebooks"
echo "[jupyter] 아래에 찍히는 http://127.0.0.1:$PORT/lab?token=… 주소를 복사해 내 PC 브라우저에 붙여 넣습니다."
exec "$VENV/bin/jupyter" lab --no-browser --ip=127.0.0.1 --port="$PORT" --ServerApp.port_retries=0
